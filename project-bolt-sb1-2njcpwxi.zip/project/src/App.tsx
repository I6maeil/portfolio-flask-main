import { Coffee, MapPin, Clock, Phone } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Coffee className="w-8 h-8 text-amber-700" />
              <span className="text-2xl font-bold text-stone-800">Café Lina</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#home" className="text-stone-700 hover:text-amber-700 transition">Accueil</a>
              <a href="#about" className="text-stone-700 hover:text-amber-700 transition">À Propos</a>
              <a href="#gallery" className="text-stone-700 hover:text-amber-700 transition">Galerie</a>
              <a href="#contact" className="text-stone-700 hover:text-amber-700 transition">Contact</a>
            </div>
          </div>
        </nav>
      </header>

      <section id="home" className="relative h-screen">
        <div className="absolute inset-0">
          <img
            src="/WhatsApp Image 2025-11-20 à 12.23.00_7670ea47.jpg"
            alt="Café Lina Interior"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        </div>
        <div className="relative z-10 h-full flex items-center justify-center text-center px-4">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
              Café Lina
            </h1>
            <p className="text-xl md:text-2xl text-white mb-8">
              Un espace chaleureux où chaque tasse raconte une histoire
            </p>
            <a
              href="#about"
              className="inline-block bg-amber-700 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-amber-800 transition transform hover:scale-105"
            >
              Découvrir
            </a>
          </div>
        </div>
      </section>

      <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-stone-800 mb-4">
              Bienvenue au Café Lina
            </h2>
            <p className="text-xl text-stone-600 max-w-3xl mx-auto">
              Un lieu moderne et accueillant où vous pouvez savourer un excellent café,
              travailler dans le confort ou simplement vous détendre avec des amis.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="text-center p-6">
              <div className="inline-block p-4 bg-amber-100 rounded-full mb-4">
                <Coffee className="w-8 h-8 text-amber-700" />
              </div>
              <h3 className="text-xl font-semibold text-stone-800 mb-2">Café de Qualité</h3>
              <p className="text-stone-600">
                Des grains soigneusement sélectionnés pour une expérience unique
              </p>
            </div>

            <div className="text-center p-6">
              <div className="inline-block p-4 bg-amber-100 rounded-full mb-4">
                <MapPin className="w-8 h-8 text-amber-700" />
              </div>
              <h3 className="text-xl font-semibold text-stone-800 mb-2">Emplacement Idéal</h3>
              <p className="text-stone-600">
                Au coeur de la ville, facilement accessible
              </p>
            </div>

            <div className="text-center p-6">
              <div className="inline-block p-4 bg-amber-100 rounded-full mb-4">
                <Clock className="w-8 h-8 text-amber-700" />
              </div>
              <h3 className="text-xl font-semibold text-stone-800 mb-2">Horaires Flexibles</h3>
              <p className="text-stone-600">
                Ouvert tous les jours pour vous servir
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="gallery" className="py-20 px-4 sm:px-6 lg:px-8 bg-stone-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-stone-800 mb-4">
              Notre Espace
            </h2>
            <p className="text-xl text-stone-600">
              Découvrez l'atmosphère unique du Café Lina
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="relative overflow-hidden rounded-2xl shadow-lg group">
              <img
                src="/WhatsApp Image 2025-11-20 à 12.23.00_7670ea47.jpg"
                alt="Intérieur du Café Lina"
                className="w-full h-96 object-cover transition transform group-hover:scale-110 duration-500"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
                <h3 className="text-white text-2xl font-semibold">Intérieur Moderne</h3>
                <p className="text-white text-sm">Un design contemporain et chaleureux</p>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-2xl shadow-lg group">
              <img
                src="/WhatsApp Image 2025-11-20 à 12.23.00_ecda03c6.jpg"
                alt="Logo Café Lina"
                className="w-full h-96 object-cover transition transform group-hover:scale-110 duration-500"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
                <h3 className="text-white text-2xl font-semibold">Notre Identité</h3>
                <p className="text-white text-sm">Un symbole de qualité et d'excellence</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-stone-800 mb-4">
              Nos Spécialités
            </h2>
            <p className="text-xl text-stone-600">
              Des saveurs qui réveilleront vos sens
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: 'Espresso', price: '12 DH', desc: 'Intense et aromatique' },
              { name: 'Cappuccino', price: '18 DH', desc: 'Crémeux et onctueux' },
              { name: 'Latte', price: '20 DH', desc: 'Doux et velouté' },
              { name: 'Macchiato', price: '16 DH', desc: 'Équilibré et raffiné' },
              { name: 'Americano', price: '14 DH', desc: 'Pur et corsé' },
              { name: 'Thé Premium', price: '15 DH', desc: 'Sélection exclusive' },
            ].map((item, index) => (
              <div key={index} className="bg-stone-50 rounded-xl p-6 hover:shadow-lg transition">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-xl font-semibold text-stone-800">{item.name}</h3>
                  <span className="text-amber-700 font-bold text-lg">{item.price}</span>
                </div>
                <p className="text-stone-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 bg-stone-800 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Venez Nous Rendre Visite
            </h2>
            <p className="text-xl text-stone-300">
              Nous serions ravis de vous accueillir
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <MapPin className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Adresse</h3>
              <p className="text-stone-300">
                Centre Ville<br />
                Maroc
              </p>
            </div>

            <div>
              <Clock className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Horaires</h3>
              <p className="text-stone-300">
                Lundi - Dimanche<br />
                8:00 - 22:00
              </p>
            </div>

            <div>
              <Phone className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Contact</h3>
              <p className="text-stone-300">
                +212 XXX XXX XXX<br />
                contact@cafelina.ma
              </p>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-stone-900 text-white py-8 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Coffee className="w-6 h-6 text-amber-500" />
            <span className="text-xl font-bold">Café Lina</span>
          </div>
          <p className="text-stone-400">
            &copy; 2025 Café Lina. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
